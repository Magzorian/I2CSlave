//Pin definitions

//Flag pin
const uint8_t FLAG_PIN = 0;

//Address pins
const uint8_t ADDRESS0_PIN = 0;
const uint8_t ADDRESS1_PIN = 0;
const uint8_t ADDRESS2_PIN = 0;